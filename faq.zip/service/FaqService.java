package egovframework.example.faq.service;

import java.util.List;

import egovframework.example.common.Criteria;

public interface FaqService {
	List<?> selectFaqList(Criteria criteria);   // 전체 조회 
	int selectDeptListTotCnt(Criteria criteria); // 총 개수 구하기
	int insert(FaqVO faqVO);                   // 부서 insert 
	FaqVO selectDept(int fno);                  // 상세조회
	int update(FaqVO faqVO);                   // update 메소드
	int delete(FaqVO faqVO); 
}

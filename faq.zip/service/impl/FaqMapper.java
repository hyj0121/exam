package egovframework.example.faq.service.impl;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import egovframework.example.common.Criteria;
import egovframework.example.faq.service.FaqVO;

@Mapper
public interface FaqMapper {
	public List<?> selectFaqList(Criteria criteria);   // 전체 조회 
	public int selectDeptListTotCnt(Criteria criteria); // 총 개수 구하기
	public int insert(FaqVO faqVO);                   // 부서 insert 
	public FaqVO selectDept(int fno);                  // 상세조회
	public int update(FaqVO faqVO);                   // update 메소드
	public int delete(FaqVO faqVO); 
}

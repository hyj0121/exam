/**
 * 
 */
package egovframework.example.faq.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import egovframework.example.common.Criteria;
import egovframework.example.faq.service.FaqService;
import egovframework.example.faq.service.FaqVO;

/**
 * @author user
 *
 */
@Service
public class FaqServiceImpl implements FaqService{

	@Autowired
	private FaqMapper faqMapper;
	
	@Override 
	public List<?> selectFaqList(Criteria criteria) {
		// TODO Auto-generated method stub
		return faqMapper.selectFaqList(criteria);
	}

	@Override
	public int selectDeptListTotCnt(Criteria criteria) {
		// TODO Auto-generated method stub
		return faqMapper.selectDeptListTotCnt(criteria);
	}

	@Override
	public int insert(FaqVO faqVO) {
		// TODO Auto-generated method stub
		return faqMapper.insert(faqVO);
	}

	@Override
	public FaqVO selectDept(int fno) {
		// TODO Auto-generated method stub
		return faqMapper.selectDept(fno);
	}

	@Override
	public int update(FaqVO faqVO) {
		// TODO Auto-generated method stub
		return faqMapper.update(faqVO);
	}

	@Override
	public int delete(FaqVO faqVO) {
		// TODO Auto-generated method stub
		return faqMapper.delete(faqVO);
	}

}

package egovframework.example.exam4;

public class A {
	/*
	 * 스프링 MVC 디자인 패턴은 Spring Framework에서 제공하는 웹 애플리케이션 아키텍처로, Model-View-Controller
	 * (MVC) 패턴을 기반으로 구성되어 있음 이 패턴은 **관심사의 분리(Separation of Concerns)**를 통해 유지보수성과
	 * 확장성을 높여줌 M: Model - 역할: 비즈니스 로직과 데이터를 담당. 예시: Java 클래스, DTO, Entity 객체 등. 구현
	 * 요소: 서비스(Service) 클래스, DAO (Data Access Object), DB 연동을 위한 리포지토리 등
	 * 
	 * V: View - 역할: 사용자에게 보여지는 화면을 담당. 예시: JSP, Thymeleaf, HTML + 템플릿 엔진 등 구현 요소:
	 * Controller가 전달한 데이터를 기반으로 화면을 렌더링
	 * 
	 * C: Controller 역할: 사용자의 요청을 받고, 적절한 서비스 호출 후 결과(View 또는 데이터를) 리턴. 구현
	 * 요소: @Controller 혹은 @RestController 어노테이션 사용
	 * 
	 * @Controller 혹은 @RestController 어노테이션 사용 요청
	 * 매핑: @RequestMapping, @GetMapping, @PostMapping 등 모델에 데이터 담기: Model, ModelAndView, @ModelAttribute
	 * 
	 * 작동 흐름 
	 * 1 사용자가 웹 페이지에서 요청을 보냄
	 * 
	 * 2 DispatcherServlet이 요청을 받아 적절한 Controller로 전달
	 * 
	 * 3 Controller가 Service 호출 → Repository/DAO → DB 조회
	 * 
	 * 4 결과 데이터를 Model에 담아 View로 전달
	 * 
	 * 5 View는 사용자에게 렌더링된 결과를 보여줌
	 */
}

package egovframework.example.exam4;


public class B {
/*	2. 아래 코드 중 누락된 부분을 추가하세요
	@Log4j2
	@Controller >> 추가
	public class DeptController {
//	        서비스 가져오기
		@Autowired >> 추가
	        private DeptService deptService; 
	...
	}
	*/
}

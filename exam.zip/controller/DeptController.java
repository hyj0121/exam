package com.simplecoding.simpledms.exam.controller;

import com.simplecoding.simpledms.dept.service.DeptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DeptController {

    private final DeptService deptService;

    @Autowired
    public DeptController(DeptService deptService) {
        this.deptService = deptService;
    }

    // 이후에 @GetMapping, @PostMapping 등 API 작성 가능
}


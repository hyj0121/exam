package com.simplecoding.simpledms.exam.qna.controller;

import com.simplecoding.simpledms.qna.service.QnaService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@RequiredArgsConstructor
public class QnaController {

    private final QnaService qnaService;

    @GetMapping("/qna/list")
    public String qnaList(Model model) {
        model.addAttribute("qnaList", qnaService.findAll());
        return "qna/list";
    }
}

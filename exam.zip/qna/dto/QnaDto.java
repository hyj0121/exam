package com.simplecoding.simpledms.exam.qna.dto;

import lombok.*;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class QnaDto {
    private Long qno;
    private String questioner;
    private String question;
    private String answer;
    private String answerer;
    private Date insertTime;
}

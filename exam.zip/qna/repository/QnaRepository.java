package com.simplecoding.simpledms.exam.qna.repository;

import com.simplecoding.simpledms.qna.entity.Qna;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QnaRepository extends JpaRepository<Qna, Long> {
}

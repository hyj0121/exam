package com.simplecoding.simpledms.exam.qna.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;

@Entity
@Table(name = "TB_QNA")
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
public class Qna {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "qna_seq")
    @SequenceGenerator(name = "qna_seq", sequenceName = "SQ_QNA", allocationSize = 1)
    private Long qno;

    private String questioner;
    private String question;
    private String answer;
    private String answerer;

    @Column(name = "INSERT_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date insertTime;

    @Column(name = "UPDATE_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateTime;
}

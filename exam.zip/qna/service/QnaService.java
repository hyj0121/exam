package com.simplecoding.simpledms.qna.service;

import com.simplecoding.simpledms.qna.dto.QnaDto;
import com.simplecoding.simpledms.qna.entity.Qna;
import com.simplecoding.simpledms.qna.repository.QnaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class QnaService {

    private final QnaRepository qnaRepository;

    public List<QnaDto> findAll() {
        return qnaRepository.findAll().stream()
                .map(q -> new QnaDto(
                        q.getQno(),
                        q.getQuestioner(),
                        q.getQuestion(),
                        q.getAnswer(),
                        q.getAnswerer(),
                        q.getInsertTime()
                ))
                .collect(Collectors.toList());
    }
}
